# School Helper v1.1.0

- **Artifact:** `school-helper-1.1.0.zip`
- **Source commit:** `fe7618bc3ee84e53ef32e1cd020faed1ed397b74`
- **Built:** 2026-09-26T19:00:48.937Z
- **SHA-256:** `1278398c2ab72ab6022215d25c002461b716fb94dda222232c9992156ac89d6b`
- **Size:** 143 KB

## Install (Chrome or Opera GX)
1. Unzip `school-helper-1.1.0.zip`.
2. Open `chrome://extensions` (Chrome) or `opera://extensions` (Opera GX).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select the unzipped folder.

Verify the download before installing:
```
certutil -hashfile school-helper-1.1.0.zip SHA256
```
