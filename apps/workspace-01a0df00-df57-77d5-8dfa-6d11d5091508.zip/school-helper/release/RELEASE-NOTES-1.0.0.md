# School Helper v1.0.0

- **Artifact:** `school-helper-1.0.0.zip`
- **Source commit:** `8f6477ce2264643088a63c6a4f69744b2cf22fd3`
- **Built:** 2026-09-26T17:49:24.195Z
- **SHA-256:** `33755b9bed02efcb5a8d3c0f9efe05f51980e6ea0c3176b1ebe8710e27d39309`
- **Size:** 128 KB

## Install (Chrome or Opera GX)
1. Unzip `school-helper-1.0.0.zip`.
2. Open `chrome://extensions` (Chrome) or `opera://extensions` (Opera GX).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select the unzipped folder.

Verify the download before installing:
```
certutil -hashfile school-helper-1.0.0.zip SHA256
```
